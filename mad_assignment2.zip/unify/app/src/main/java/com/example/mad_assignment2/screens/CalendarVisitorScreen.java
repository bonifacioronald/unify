package com.example.mad_assignment2.screens;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mad_assignment2.R;
public class  CalendarVisitorScreen extends AppCompatActivity  {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_visitor_screen);

}
}
